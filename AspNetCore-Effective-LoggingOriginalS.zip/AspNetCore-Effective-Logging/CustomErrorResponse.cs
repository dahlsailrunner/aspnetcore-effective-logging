﻿namespace CoreFlogger
{
    public class CustomErrorResponse
    {
        public string ErrorId { get; set; }
        public string Message { get; set; }
    }
}
